<?php
  $servername = "localhost"; 
  $username = "root";
  $password = "";
  $db_name = "eRevenue";

  $conn = new mysqli($servername, $username, $password, $db_name);

  if($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  if($_SERVER["REQUEST_METHOD"] == "POST") {
    function clean_input($data) {
      return htmlspecialchars(stripslashes($data));
    }

    $errors = [];

    $full_name = clean_input($_POST["full_name"]);
    if (empty($full_name) || strlen($full_name) < 3) {
      $errors[] = "Fullname is required and must be at least 3 characters";
    }

    $nid_number = clean_input($_POST["nid_number"]);
    if (!preg_match('/^\d{10,17}$/', $nid_number)) {
      $errors[] = "Invalid NID";
    }

    $tin_number = clean_input($_POST["tin_number"]);
    if (!preg_match('/^\d{12}$/', $tin_number)) {
      $errors[] = "Invalid TIN";
    }

    $dob = clean_input($_POST["dob"]);
    if (empty($dob)) {
      $errors[] = "Date of birth is required";
    }

    $email = clean_input($_POST["email"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors[] = "Invalid Email";
    }

    $phone = clean_input($_POST["phone"]);
    if (!preg_match('/^01[3-9]\d{8}$/', $phone)) {
      $errors[] = "Invalid Phone";
    }

    $occupation = clean_input($_POST["occupation"]);

    $address = clean_input($_POST["address"]);

    $password = clean_input($_POST["password"]);
    if (strlen($password) < 8) {
      $errors[] = "Password must be at least 8 characters.";
    }

    if (!empty($errors)) {
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $is_active = TRUE;
    $role = "taxpayer";

    $email_exists = FALSE;

    $check_sql = "SELECT id FROM users WHERE email = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param('s', $email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        echo json_encode(["status" => "exists", "message" => "Email already registered"]);
        $email_exists = TRUE;
        exit;
    } else {
        echo json_encode(["status" => "ok", "message" => "Email is available"]);
    }

    $check_stmt->close();

    if(!$email_exists) { 
      $sql = "INSERT INTO users(email, phone, password_hash, full_name, role, is_active, date_of_birth, nid, tin, occupation, address) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      $query = $conn->prepare($sql);
      $query->bind_param("sssssssssss", $email, $phone, $hashed_password, $full_name, $role, $is_active, $dob, $nid_number, $tin_number, $occupation, $address);

      if ($query->execute()) {
        echo json_encode(['success' => true, 'message' => "Form submitted successfully."]);
        header("Location: login.php");
          exit;
      } else {
          echo json_encode(['success' => false, 'message' => "Error: " . $query->error]);
      }

      $query->close();
    }
    $conn->close();
  }
?>