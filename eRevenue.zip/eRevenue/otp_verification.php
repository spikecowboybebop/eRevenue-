<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost"; 
$username = "root";
$password = "";
$db_name = "eRevenue";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$otp= isset($_POST['otp']) ? clean_input($_POST['otp']) : '';

$sql = "SELECT token FROM two_factor_tokens WHERE token = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $otp);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}

$stmt->close();
$conn->close();

?>