<?php
session_start();
header('Content-Type: application/json');

function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$otp= isset($_POST['otp']) ? clean_input($_POST['otp']) : '';

if (time() > $_SESSION['expires_at']) {
    echo "OTP expired.";
} elseif ($otp == $_SESSION['otp']) {
    echo json_encode(["success" => true]);
    unset($_SESSION['otp']);
    unset($_SESSION['otp_expires']);
} else {
    echo json_encode(["success" => false]);
}
?>
