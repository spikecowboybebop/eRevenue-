<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Create Account</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .error {
      border-color: red;
    }
    .error-text {
      color: red;
      font-size: 0.875rem;
      margin-top: 0.25rem;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <div class="flex min-h-screen items-center justify-center p-4">
    <div class="bg-white shadow-2xl rounded-3xl w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 overflow-hidden">
      
      <!-- Illustration -->
      <div class="bg-gradient-to-br from-purple-100 via-white to-pink-100 flex items-center justify-center p-6">
        <img src="Assets/signup-illustration.jpg" alt="Illustration" class="max-w-full h-auto object-contain" />
      </div>

      <!-- Form Area -->
      <div class="p-6 sm:p-10">
        <div class="mb-6">
          <div class="flex items-center space-x-2">
            <img width="50" height="50" src="https://img.icons8.com/isometric-line/50/bank.png" alt="bank" />
          </div>
          <h1 class="text-3xl font-bold text-gray-900 mb-2">Create an account</h1>
          <p class="text-gray-600">Sign up now and unlock exclusive access!</p>
        </div>

        <!-- Progress Bar -->
        <div class="mb-6">
          <div class="flex justify-between mb-1 text-sm text-gray-600">
            <span>Step <span id="stepNumber">1</span> of 3</span>
          </div>
          <div class="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
            <div id="progress" class="h-full bg-purple-600 transition-all duration-300" style="width: 33%;"></div>
          </div>
        </div>

        <!-- Multi-Step Form -->
        <form id="multiStepForm">
          <!-- Step 1 -->
          <div class="step" id="step-1">
            <label class="block text-sm font-medium mb-1">Full Name</label>
            <input type="text" id="full_name" class="w-full mb-1 px-4 py-2 border rounded-md" name="full_name"/>
            <p id="error_full_name" class="error-text hidden"></p>

            <label class="block text-sm font-medium mt-4 mb-1">NID Number</label>
            <input type="text" id="nid_number" class="w-full mb-1 px-4 py-2 border rounded-md" name="nid_number"/>
            <p id="error_nid_number" class="error-text hidden"></p>

            <label class="block text-sm font-medium mt-4 mb-1">TIN Number</label>
            <input type="text" id="tin_number" class="w-full mb-1 px-4 py-2 border rounded-md" name="tin_number"/>
            <p id="error_tin_number" class="error-text hidden"></p>

            <div class="flex justify-end mt-4">
              <button type="button" onclick="nextStep()" class="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700">Next</button>
            </div>
          </div>

          <!-- Step 2 -->
          <div class="step hidden" id="step-2">
            <label class="block text-sm font-medium mb-1">Date of Birth</label>
            <input type="date" id="dob" class="w-full mb-1 px-4 py-2 border rounded-md" name="dob"/>
            <p id="error_dob" class="error-text hidden"></p>

            <label class="block text-sm font-medium mt-4 mb-1">Email</label>
            <input type="email" id="email" class="w-full mb-1 px-4 py-2 border rounded-md" name="email"/>
            <p id="error_email" class="error-text hidden"></p>

            <label class="block text-sm font-medium mt-4 mb-1">Phone</label>
            <input type="tel" id="phone" class="w-full mb-1 px-4 py-2 border rounded-md" name="phone"/>
            <p id="error_phone" class="error-text hidden"></p>

            <div class="flex justify-between mt-4">
              <button type="button" onclick="prevStep()" class="bg-gray-300 text-gray-800 px-6 py-2 rounded-md hover:bg-gray-400">Back</button>
              <button type="button" onclick="nextStep()" class="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700">Next</button>
            </div>
          </div>

          <!-- Step 3 -->
          <div class="step hidden" id="step-3">

            <!-- Occupation -->
            <label class="block text-sm font-medium mb-1">Occupation</label>
            <input type="text" id="occupation" class="w-full mb-1 px-4 py-2 border rounded-md" name="occupation" />
            <p id="error_occupation" class="error-text hidden"></p>

            <!-- Address -->
            <label class="block text-sm font-medium mt-4 mb-1">Address</label>
            <input type="text" id="address" class="w-full mb-1 px-4 py-2 border rounded-md" name="address" />
            <p id="error_address" class="error-text hidden"></p>

            <!-- Password -->
            <label class="block text-sm font-medium mt-4 mb-1">Password</label>
            <input type="password" id="password" class="w-full mb-1 px-4 py-2 border rounded-md" name="password" />
            <p id="error_password" class="error-text hidden"></p>

            <div class="flex justify-between mt-4">
              <button type="button" onclick="prevStep()" class="bg-gray-300 text-gray-800 px-6 py-2 rounded-md hover:bg-gray-400">Back</button>
              <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">Submit</button>
            </div>
          </div>
        </form>

        <!-- Footer Links -->
        <p class="mt-6 text-base text-gray-600">Already an User? <a href="login.php" class="font-bold text-red-400 hover:underline">Sign In</a></p>
        <p class="mt-2 text-base text-sky-800">Get help signing in</p>
        <div class="mt-2 flex items-center space-x-2">
          <img src="https://img.icons8.com/tiny-glyph/16/new-post.png" alt="Mail Icon" class="w-4 h-4" />
          <span class="text-base text-gray-700">help@erevenue.bd</span>
        </div>
      </div>
    </div>
  </div>

  <!-- JavaScript -->
  <script>
    let currentStep = 1;
    const form = document.getElementById("multiStepForm");
    const inputs = form.querySelectorAll("input");

    function showStep(step) {
      document.querySelectorAll('.step').forEach((el, idx) => {
        el.classList.toggle('hidden', idx !== step - 1);
      });
      document.getElementById('progress').style.width = `${step * 33.33}%`;
      document.getElementById('stepNumber').innerText = step;
    }

    const validators = {
      full_name: val => val.trim() !== '' || "Full name is required.",
      nid_number: val => /^\d{10,17}$/.test(val) || "NID must be 10 to 17 digits.",
      tin_number: val => /^\d{12}$/.test(val) || "TIN must be exactly 12 digits.",
      dob: val => {
        const d = new Date(val);
        const now = new Date();
        const age = now.getFullYear() - d.getFullYear();
        return val && age >= 18 ? true : "You must be at least 18 years old.";
      },
      email: val => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val) || "Enter a valid email address.",
      phone: val => /^01[3-9]\d{8}$/.test(val) || "Enter a valid Bangladeshi phone number.",
      occupation: val => val.trim() !== '' || "Occupation is required.",
      address: val => val.trim() !== '' || "Address is required.",
      password: val => val.length >= 8 || "Password must be at least 8 characters.",
    };

    function validateField(id) {
      const input = document.getElementById(id);
      const errorEl = document.getElementById(`error_${id}`);
      const rule = validators[id];
      if (!rule) return true;

      const result = rule(input.value);
      if (result !== true) {
        input.classList.add("error");
        errorEl.innerText = result;
        errorEl.classList.remove("hidden");
        return false;
      } else {
        input.classList.remove("error");
        errorEl.innerText = "";
        errorEl.classList.add("hidden");
        return true;
      }
    }

    inputs.forEach(input => {
      input.addEventListener("input", () => validateField(input.id));
    });

    function validateStep(step) {
      const stepFields = {
        1: ["full_name", "nid_number", "tin_number"],
        2: ["dob", "email", "phone"],
        3: ["occupation", "address", "password"],
      };

      const fields = stepFields[step];
      return fields.map(validateField).every(Boolean);
    }

    function nextStep() {
      if (validateStep(currentStep)) {
        currentStep++;
        showStep(currentStep);
      }
    }

    function prevStep() {
      if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
      }
    }

form.addEventListener("submit", function (e) {
  e.preventDefault();
  
  if (!validateStep(currentStep)) {
    return; // Don't proceed if validation fails
  }

  const formData = new FormData(form);
  
  // First check if user exists
  fetch('check_user.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if(data.success) {
      Swal.fire({
        title: "User Already Exists!",
        text: "Taking you to Login Page",
        icon: "warning"
      }).then(() => {
        window.location.href = 'login.php';
      });
    } else {
      // If user doesn't exist, proceed with registration
      return fetch('register.php', {
        method: 'POST',
        body: formData
      });
    }
  })
  .then(response => {
    if (!response) return; // Skip if we already handled the exists case
    return response.json();
  })
  .then(data => {
    if (data && data.success) {
      Swal.fire({
        title: "Success!",
        text: "Your account has been created successfully!",
        icon: "success"
      }).then(() => {
        window.location.href = 'login.php'; // Redirect to login page
      });
    } else if (data && data.error) {
      Swal.fire({
        title: "Error!",
        text: data.error,
        icon: "error"
      });
    }
  })
  .catch(error => {
    console.error(error);
    Swal.fire({
      title: "Error!",
      text: "An error occurred during registration.",
      icon: "error"
    });
  });
});

    showStep(currentStep);
  </script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>

