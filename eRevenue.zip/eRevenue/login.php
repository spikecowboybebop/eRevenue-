<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .slide-transition {
      transition: transform 0.5s ease-in-out;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <div class="flex min-h-screen items-center justify-center">
    <div class="bg-white shadow-2xl rounded-3xl w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">
      <div class="bg-gradient-to-br from-purple-100 via-white to-pink-100 flex items-center justify-center p-6">
        <img src="Assets\login-illustration.jpg" alt="Illustration" class="max-w-full h-auto" />
      </div>

      <div class="p-10">
        <div class="mb-6">
          <div class="flex items-center space-x-2">
            <img width="50" height="50" src="https://img.icons8.com/isometric-line/50/bank.png" alt="bank"/>
          </div>
          <h1 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h1>
          <p class="text-gray-600">Please sign in to continue</p>
        </div>

        <div class="relative w-full overflow-hidden">
          <div id="slider" class="flex w-[200%] slide-transition">

            <!-- Step 1: Email & Password -->
            <div class="w-full box-border px-1">
              <form id="loginForm">
                <label class="block text-sm font-medium mb-1">Email Address</label>
                <input type="email" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="you@example.com" />

                <label class="block text-sm font-medium mb-1">Password</label>
                <input type="password" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="••••••••" />

                <div class="flex justify-between items-center mb-4">
                  <label class="flex items-center text-sm">
                    <input type="checkbox" class="mr-2" /> Remember me
                  </label>
                  <a href="#" class="text-sm text-purple-600 hover:underline">Forgot password?</a>
                </div>

                <button type="submit" class="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700">
                  Continue
                </button>
              </form>
            </div>

            <!-- Step 2: 2FA Code -->
            <div class="w-full box-border px-1">
              <form id="otpForm">
                <label class="block text-sm font-medium mb-1">Two-Factor Authentication Code</label>
                <input type="text" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="Enter your 2FA code" />

                <button type="submit" class="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700">
                  Verify
                </button>

                <button type="button" id="backBtn" class="w-full mt-2 bg-gray-200 text-gray-800 py-2 rounded-md hover:bg-gray-300">
                  Back
                </button>
              </form>
            </div>
          </div>
        </div>

        <!-- Help Text and Mail Icon Info -->
        <p class="mt-6 text-base text-gray-600 mb-1">New User? <a href="" class="mt-6 text-base font-bold text-red-400 mb-1 no-underline hover:underline">Create An Account</a></p>
        <p class="mt-2 text-base text-sky-800 mb-1">Get help signing in</p>
        <div class="mt-2 flex items-center space-x-2">
          <img src="https://img.icons8.com/tiny-glyph/16/new-post.png" alt="Mail Icon" class="w-4 h-4" />
          <span class="text-base text-gray-700">help@erevenue.bd</span>
        </div>
      </div>
    </div>
  </div>

  <script>
    const loginForm = document.getElementById('loginForm');
    const otpForm = document.getElementById('otpForm');
    const slider = document.getElementById('slider');
    const backBtn = document.getElementById('backBtn');

    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      slider.style.transform = 'translateX(-50%)';
    });

    backBtn.addEventListener('click', () => {
      slider.style.transform = 'translateX(0%)';
    });

    otpForm.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('2FA Verified. Logging in...');
    });
  </script>
</body>
</html>
