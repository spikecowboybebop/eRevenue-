<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .slide-transition {
      transition: transform 0.5s ease-in-out;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <div class="flex min-h-screen items-center justify-center px-4 sm:px-6 lg:px-8">
    <div class="bg-white shadow-2xl rounded-3xl w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">

      <!-- Left Side: Illustration -->
      <div class="bg-gradient-to-br from-purple-100 via-white to-pink-100 flex items-center justify-center p-6">
        <img src="Assets/login-illustration.jpg" alt="Illustration" class="max-w-full h-auto object-contain" />
      </div>

      <!-- Right Side: Login Form -->
      <div class="p-6 sm:p-10">
        <div class="mb-6">
          <div class="flex items-center space-x-2 mb-2">
            <img width="50" height="50" src="https://img.icons8.com/isometric-line/50/bank.png" alt="bank"/>
          </div>
          <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-1">Welcome Back</h1>
          <p class="text-sm sm:text-base text-gray-600">Please sign in to continue</p>
        </div>

        <div class="relative w-full overflow-hidden">
          <div id="slider" class="flex w-[200%] slide-transition">

            <!-- Step 1: Email & Password -->
            <div class="w-full box-border px-1">
              <form id="loginForm">
                <label class="block text-sm font-medium mb-1">Email Address</label>
                <input type="email" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="you@example.com" name="email"/>

                <label class="block text-sm font-medium mb-1">Password</label>
                <input type="password" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="••••••••" name="password"/>

                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-2">
                  <label class="flex items-center text-sm">
                    <input type="checkbox" class="mr-2" /> Remember me
                  </label>
                  <a href="#" class="text-sm text-purple-600 hover:underline">Forgot password?</a>
                </div>

                <button type="submit" class="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700">
                  Continue
                </button>
              </form>
            </div>

            <!-- Step 2: 2FA -->
            <div class="w-full box-border px-1">
              <form id="otpForm">
                <label class="block text-sm font-medium mb-1">Two-Factor Authentication Code</label>
                <input type="text" required class="w-full mb-4 px-4 py-2 border rounded-md" placeholder="Enter your 2FA code" name="otp"/>

                <button type="submit" class="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700">
                  Verify
                </button>

                <button type="button" id="backBtn" class="w-full mt-2 bg-gray-200 text-gray-800 py-2 rounded-md hover:bg-gray-300">
                  Back
                </button>
              </form>
            </div>
          </div>
        </div>

        <!-- Help Info -->
        <div class="mt-6">
          <p class="text-sm sm:text-base text-gray-600">
            New User? 
            <a href="signup.php" class="text-red-400 font-semibold hover:underline">Create An Account</a>
          </p>
          <p class="mt-2 text-sm sm:text-base text-sky-800">Get help signing in</p>
          <div class="mt-1 flex items-center space-x-2">
            <img src="https://img.icons8.com/tiny-glyph/16/new-post.png" alt="Mail Icon" class="w-4 h-4" />
            <span class="text-sm sm:text-base text-gray-700">help@erevenue.bd</span>
          </div>
        </div>
      </div>

    </div>
  </div>

  <script>
    const loginForm = document.getElementById('loginForm');
    const otpForm = document.getElementById('otpForm');
    const slider = document.getElementById('slider');
    const backBtn = document.getElementById('backBtn');

    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const formData = new FormData(loginForm);
      fetch('login_verification.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if(data.success) {
          slider.style.transform = 'translateX(-50%)';
        }
        else {
          Swal.fire({
            title: "Your entered Email and Password is wrong!",
            text: "Please enter your correct credentials",
            icon: "error"
          });
        }
      })
    });

    backBtn.addEventListener('click', () => {
      slider.style.transform = 'translateX(0%)';
    });

    otpForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const otpData = new FormData(otpForm);
      fetch('otp_verification.php', {
        method: 'POST',
        body: otpData
      })
      .then(response => response.json())
      .then(data => {
        if(data.success) {
          Swal.fire({
            title: "Success",
            text: "Redirecting you to dashboard",
            icon: "success"
          }).then(() => {
            window.location.href = "dashboard_user.php";
          });
        }
        else {
          Swal.fire({
            title: "Wrong OTP",
            text: "Your OTP is wrong",
            icon: "error"
          });
        }
      })
    });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
