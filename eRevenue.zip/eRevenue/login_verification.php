<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost"; 
$username = "root";
$password = "";
$db_name = "eRevenue";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Get and sanitize inputs
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$email = isset($_POST['email']) ? clean_input($_POST['email']) : '';
$password = isset($_POST['password']) ? clean_input($_POST['password']) : '';
$password_hash;
$user_id;

// Build query
$sql = "SELECT id, password_hash FROM users WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id, $password_hash);
$stmt->fetch();
$verify = password_verify($password, $password_hash);

//Token Generator
function generateRandomToken($length):string {
  return bin2hex(random_bytes($length / 2));
}
$token = generateRandomToken(6);
$expires_at = time() + (3 * 60);
$created_at = time();
$used = FALSE;
$token_sql = "INSERT INTO two_factor_tokens(user_id, token, expires_at, used, created_at) VALUES(?, ?, ?, ?, ?)";
$token_stmt = $conn->prepare($token_sql);
$token_stmt->bind_param("sssss", $user_id, $token, $expires_at, $used, $created_at);
$token_stmt->execute();

// Check result
if ($stmt->num_rows > 0 AND $verify) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}

$stmt->close();
$conn->close();
?>