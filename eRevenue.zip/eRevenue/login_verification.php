<?php
session_start();
header('Content-Type: application/json');

require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection
$servername = "localhost"; 
$username = "root";
$password = "";
$db_name = "eRevenue";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Get and sanitize inputs
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$email = isset($_POST['email']) ? clean_input($_POST['email']) : '';
$password = isset($_POST['password']) ? clean_input($_POST['password']) : '';
$password_hash;
$user_id;

// Build query
$sql = "SELECT id, password_hash FROM users WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($user_id, $password_hash);
$stmt->fetch();
$verify = password_verify($password, $password_hash);

//Token Generator
function generateRandomToken($length):string {
  return bin2hex(random_bytes($length / 2));
}

// Check result
if ($stmt->num_rows > 0 AND $verify) {
    echo json_encode(["success" => true]);
    $token = rand(100000, 999999);
    $expires_at = time() + (3 * 60);

    $_SESSION['otp'] = $token;
    $_SESSION['email'] = $email;
    $_SESSION['expires_at'] = $expires_at;

    $mail = new PHPMailer(true);
    try {
        // SMTP setup
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';          // or smtp.mailtrap.io
        $mail->SMTPAuth = true;
        $mail->Username = 'erevenue37@gmail.com';      // your email
        $mail->Password = 'jzmb fnvt tzct ixyy';   // app password (not normal password)
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Email content
        $mail->setFrom('erevenue37@gmail.com', 'eRevenue');
        $mail->addAddress($email); // user's email
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body    = "Your 2FA OTP is: <b>$token</b><br>This code expires in 3 minutes.";

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Error: {$mail->ErrorInfo}";
    }
    } else {
        echo json_encode(["success" => false]);
    }
$stmt->close();
$conn->close();
?>