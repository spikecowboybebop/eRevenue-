<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost"; 
$username = "root";
$password = "";
$db_name = "eRevenue";

$conn = new mysqli($servername, $username, $password, $db_name);

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Get and sanitize inputs
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$email = isset($_POST['email']) ? clean_input($_POST['email']) : '';
$phone = isset($_POST['phone']) ? clean_input($_POST['phone']) : '';
$nid = isset($_POST['nid_number']) ? clean_input($_POST['nid_number']) : '';
$tin = isset($_POST['tin_number']) ? clean_input($_POST['tin_number']) : '';

// Build query
$sql = "SELECT id FROM users WHERE email = ? OR phone = ? OR nid = ? OR tin = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $email, $phone, $nid, $tin);
$stmt->execute();
$stmt->store_result();

// Check result
if ($stmt->num_rows > 0) {
    echo json_encode(["success" => true, "message" => "User already exists"]);
} else {
    echo json_encode(["success" => false, "message" => "User does not exist"]);
}

$stmt->close();
$conn->close();
?>
