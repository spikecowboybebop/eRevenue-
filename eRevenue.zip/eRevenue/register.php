<?php
header('Content-Type: application/json');

$servername = "localhost"; 
$username = "root";
$password = "";
$db_name = "eRevenue";

$conn = new mysqli($servername, $username, $password, $db_name);

if($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => "Database connection failed"]));
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    function clean_input($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    $errors = [];

    // Validate all fields
    $full_name = clean_input($_POST["full_name"] ?? '');
    if (empty($full_name)) {
        $errors['full_name'] = "Full name is required";
    } elseif (strlen($full_name) < 3) {
        $errors['full_name'] = "Full name must be at least 3 characters";
    }

    $nid_number = clean_input($_POST["nid_number"] ?? '');
    if (!preg_match('/^\d{10,17}$/', $nid_number)) {
        $errors['nid_number'] = "NID must be 10-17 digits";
    }

    $tin_number = clean_input($_POST["tin_number"] ?? '');
    if (!preg_match('/^\d{12}$/', $tin_number)) {
        $errors['tin_number'] = "TIN must be exactly 12 digits";
    }

    $dob = clean_input($_POST["dob"] ?? '');
    if (empty($dob)) {
        $errors['dob'] = "Date of birth is required";
    } else {
        $age = date_diff(date_create($dob), date_create('today'))->y;
        if ($age < 18) {
            $errors['dob'] = "You must be at least 18 years old";
        }
    }

    $email = clean_input($_POST["email"] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format";
    }

    $phone = clean_input($_POST["phone"] ?? '');
    if (!preg_match('/^01[3-9]\d{8}$/', $phone)) {
        $errors['phone'] = "Invalid Bangladeshi phone number";
    }

    $occupation = clean_input($_POST["occupation"] ?? '');

    $address = clean_input($_POST["address"] ?? '');

    $password = $_POST["password"] ?? '';
    if (strlen($password) < 8) {
        $errors['password'] = "Password must be at least 8 characters";
    }

    // Return validation errors if any
    if (!empty($errors)) {
        echo json_encode(['success' => false, 'errors' => $errors]);
        $conn->close();
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $is_active = true;
    $role = "taxpayer";
    $verified = FALSE;

    // Insert new user
    $sql = "INSERT INTO users(email, phone, password_hash, full_name, role, is_active, date_of_birth, nid, tin, occupation, address, verified) 
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $query = $conn->prepare($sql);
    $query->bind_param("ssssssssssss", $email, $phone, $hashed_password, $full_name, $role, $is_active, $dob, $nid_number, $tin_number, $occupation, $address, $verified);

    if ($query->execute()) {
        echo json_encode(['success' => true, 'message' => "Registration successful"]);
    } else {
        echo json_encode(['success' => false, 'message' => "Registration failed: " . $query->error]);
    }

    $query->close();
    $conn->close();
}
?>