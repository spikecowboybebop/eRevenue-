<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Responsive Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Sidebar transition for mobile */
    #sidebar {
      transition: transform 0.3s ease-in-out;
    }
  </style>
</head>
<body class="flex h-screen overflow-hidden bg-gray-100">
  <!-- Overlay for mobile sidebar -->
  <div id="overlay" class="fixed inset-0 bg-black opacity-50 z-30 hidden lg:hidden"></div>

  <!-- Sidebar -->
  <div id="sidebar" class="fixed lg:relative z-[100] h-full w-64 bg-white shadow-2xl lg:shadow-lg transform -translate-x-full lg:translate-x-0">
    <nav class="flex flex-col h-full p-4 space-y-2">
      <div class="text-2xl font-bold text-blue-600 mb-6">Dashboard</div>
      <button class="tab-link px-4 py-2 text-left rounded hover:bg-blue-50 bg-blue-100 font-bold" data-target="dashboard-view">Dashboard</button>
      <button class="tab-link px-4 py-2 text-left rounded hover:bg-blue-50" data-target="users-view">Users</button>
      <button class="tab-link px-4 py-2 text-left rounded hover:bg-blue-50" data-target="settings-view">Settings</button>
    </nav>
  </div>

  <!-- Main Content -->
  <div class="flex flex-col flex-1 overflow-hidden">
    <!-- Header for mobile -->
    <header class="flex items-center justify-between p-4 bg-white shadow-md lg:hidden">
      <button id="menu-toggle" class="text-gray-700 focus:outline-none">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <h1 class="text-lg font-semibold text-gray-800">eRevenue</h1>
    </header>

    <!-- Tabs Content -->
    <main class="flex-1 overflow-y-auto p-6">
      <div id="dashboard-view">
        <h2 class="text-2xl font-semibold mb-4">Welcome to the Dashboard</h2>
        <p>This is your main overview screen.</p>
      </div>
      <div id="users-view" class="hidden">
        <div class="mb-8"></div>
        <div class="w-full max-w-5xl mx-auto">
          <div class="relative w-full bg-white p-6 md:p-10 rounded-2xl shadow-md">
            <div class="absolute -top-7 left-6 z-10">
              <div class="bg-white border border-blue-600 px-6 py-2 rounded-lg shadow">
                <h3 class="text-xl md:text-2xl font-bold text-blue-700">Income Tax Calculator</h3>
              </div>
            </div>
            <form id="multiStepForm">
              <!-- Step 1 -->
              <div class="step" id="step-1">
                <h3 class="text-xl font-bold mb-4 mt-4 text-cyan-500">Income Details (Fiscal Year)</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-2">
                  <div>
                    <label for="basicSalary" class="block font-semibold mb-1">Basic Salary:</label>
                    <input type="text" id="basicSalary" name="basicSalary" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Your basic salary before any deductions</p>
                  </div>
                  <div>
                    <label for="houseRent" class="block font-semibold mb-1">House Rent Allowance:</label>
                    <input type="text" id="houseRent" name="houseRent" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Allowance for House Rent (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="conveyance" class="block font-semibold mb-1">Conveyance Allowance:</label>
                    <input type="text" id="conveyance" name="conveyance" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Allowance for commuting (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="medical" class="block font-semibold mb-1">Medical Allowance:</label>
                    <input type="text" id="medical" name="medical" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Allowance for medical expenses (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="bonuses" class="block font-semibold mb-1">Bonuses:</label>
                    <input type="text" id="bonuses" name="bonuses" class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Include any bonuses (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="overtime" class="block font-semibold mb-1">Overtime Allowance:</label>
                    <input type="text" id="overtime" name="overtime" class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Payment for overtime work (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="otherIncome" class="block font-semibold mb-1">Other Income:</label>
                    <input type="text" id="otherIncome" name="otherIncome" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Other Taxable Income (Enter '0' if not applicable)</p>
                  </div>
                  <div>
                    <label for="ait" class="block font-semibold mb-1">Advance Income Tax (AIT):</label>
                    <input type="text" id="ait" name="ait" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Tax already paid in advance (Enter '0' if not applicable)</p>
                  </div>
                </div>
                <div class="flex justify-end mb-10 mt-4">
                  <button type="button" class="mt-6 next bg-blue-600 text-white px-6 py-2 rounded font-semibold shadow hover:bg-blue-700">Next</button>
                </div>
              </div>
              <!-- Step 2 -->
              <div class="step hidden" id="step-2">
                <h3 class="text-xl font-bold mb-4 mt-4 text-cyan-500">Investments</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-2">
                  <div>
                    <label for="basicSalary" class="block font-semibold mb-1">Sanchay Patra:</label>
                    <input type="text" id="basicSalary" name="basicSalary" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Max Rebate Eligible: BDT 500,000 (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="houseRent" class="block font-semibold mb-1">DPS (Deposit Pension Scheme):</label>
                    <input type="text" id="houseRent" name="houseRent" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Max Rebate Eligible: BDT 120,000 (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="conveyance" class="block font-semibold mb-1">Mutual Fund:</label>
                    <input type="text" id="conveyance" name="conveyance" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Full Amount eligible for Tax Rebate (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="medical" class="block font-semibold mb-1">Treasury Bond:</label>
                    <input type="text" id="medical" name="medical" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Full Amount eligible for Tax Rebate (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="bonuses" class="block font-semibold mb-1">Stock:</label>
                    <input type="text" id="bonuses" name="bonuses" class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Full Amount eligible for Tax Rebate (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="overtime" class="block font-semibold mb-1">Provident Fund (Employee's Contribution):</label>
                    <input type="text" id="overtime" name="overtime" class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Full Amount eligible (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="otherIncome" class="block font-semibold mb-1">Provident Fund (Employer's Contribution):</label>
                    <input type="text" id="otherIncome" name="otherIncome" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Full Amount eligible (Enter '0' if none)</p>
                  </div>
                  <div>
                    <label for="ait" class="block font-semibold mb-1">Provident Fund (Net Interest, after 27.5%)</label>
                    <input type="text" id="ait" name="ait" required class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500" />
                    <p class="text-sm text-gray-500 mt-1">Net Interest after Tax (Enter '0' if none)</p>
                  </div>
                </div>
                <div class="flex justify-between mb-10 mt-10">
                  <button type="button" class="prev bg-gray-500 text-white px-6 py-2 rounded font-semibold shadow hover:bg-gray-600">Previous</button>
                  <button type="button" class="next bg-blue-600 text-white px-6 py-2 rounded font-semibold shadow hover:bg-blue-700">Next</button>
                </div>
              </div>
              <!-- Step 3 -->
              <div class="step hidden" id="step-3">
                <h3 class="text-xl font-bold mb-4 mt-7 text-cyan-500">Category and Tax-Free Slab</h3>
                <div class="mb-6">
                  <label for="summaryOption" class="block font-semibold mb-2">Select Your Category:</label>
                  <select id="summaryOption" name="summaryOption" class="w-full rounded-lg border border-gray-300 px-4 py-2 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    <option value="General Man">General Man - BDT 350,000</option>
                    <option value="Woman">Woman - BDT 400,000</option>
                    <option value="Older Citizen">65 years or older citizen - BDT 400,000</option>
                    <option value="Disabled">Physical or Mental unfit person - BDT 475,000</option>
                    <option value="FFighter">Gazetted Freedom Fighter - BDT 500,000</option>
                    <option value="Third"> Third Gender - BDT 475,000</option>
                  </select>
                </div>
                <div class="mb-4 text-gray-700">
                  <h3 class="text-xl font-bold mb-4 mt-7 text-cyan-500">Children Adjustment</h3>
                  <div>
                    <label for="childrenAdjustment" class="block font-semibold mb-1">Parents of Physical or Mental unfit person will add 50,000 BDT per child: </label>
                    <input type="text" id="childrenAdjustment" name="childrenAdjustment" class="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-base shadow-sm focus:border-blue-500 focus:ring-blue-500"/>
                    <p class="text-sm text-gray-500 mt-1">Enter the number of children if applicable</p>
                  </div>
                </div>
                <div class="flex justify-between mb-10 mt-10">
                  <button type="button" class="prev bg-gray-500 text-white px-6 py-2 rounded font-semibold shadow hover:bg-gray-600">Previous</button>
                  <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded font-semibold shadow hover:bg-green-700">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div id="settings-view" class="hidden">
        <h2 class="text-2xl font-semibold mb-4">Settings</h2>
        <p>Manage your application settings here.</p>
      </div>
    </main>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const menuBtn = document.getElementById("menu-toggle");
      const sidebar = document.getElementById("sidebar");
      const overlay = document.getElementById("overlay");
      const tabLinks = document.querySelectorAll(".tab-link");
      const tabViews = document.querySelectorAll("[id$='view']");

      function activateTab(targetId) {
        tabLinks.forEach((link) => {
          link.classList.remove("bg-blue-100", "font-bold");
          if (link.getAttribute("data-target") === targetId) {
            link.classList.add("bg-blue-100", "font-bold");
          }
        });
        tabViews.forEach((view) => view.classList.add("hidden"));
        const targetView = document.getElementById(targetId);
        if (targetView) {
          targetView.classList.remove("hidden");
        }
        // Save active tab to localStorage
        localStorage.setItem("activeTab", targetId);
      }

      // Load tab from localStorage or default to dashboard
      const savedTab = localStorage.getItem("activeTab") || "dashboard-view";
      activateTab(savedTab);

      tabLinks.forEach((link) => {
        link.addEventListener("click", () => {
          const target = link.getAttribute("data-target");
          activateTab(target);
          sidebar.classList.add("-translate-x-full");
          overlay.classList.add("hidden");
        });
      });

      menuBtn.addEventListener("click", () => {
        sidebar.classList.toggle("-translate-x-full");
        overlay.classList.toggle("hidden");
      });

      overlay.addEventListener("click", () => {
        sidebar.classList.add("-translate-x-full");
        overlay.classList.add("hidden");
      });

      // Multi-step form logic
      const steps = document.querySelectorAll("#multiStepForm .step");
      let currentStep = 0;

      function showStep(index) {
        steps.forEach((step, i) => {
          step.classList.toggle("hidden", i !== index);
        });
        currentStep = index;
      }
      showStep(0);

      document.getElementById("multiStepForm").addEventListener("click", function (e) {
        if (e.target.classList.contains("next")) {
          e.preventDefault();
          if (currentStep < steps.length - 1) showStep(currentStep + 1);
        }
        if (e.target.classList.contains("prev")) {
          e.preventDefault();
          if (currentStep > 0) showStep(currentStep - 1);
        }
      });
    });
  </script>
</body>
</html>
  </script>
</body>
</html>
